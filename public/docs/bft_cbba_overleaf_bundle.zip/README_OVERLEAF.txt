=== OVERLEAF COMPILATION INSTRUCTIONS ===
1. Go to https://www.overleaf.com/
2. Click 'New Project' -> 'Upload Project' -> Select this zip file (bft_cbba_overleaf_bundle.zip).
3. Overleaf will unpack preprint_ieee_bft_cbba.tex and both JPG and PNG figure formats.
4. Set compiler to pdfLaTeX (default) or XeLaTeX.
5. Click 'Recompile'.
The 6-page IEEE paper will compile cleanly with all figures, equations, algorithms, and references!
